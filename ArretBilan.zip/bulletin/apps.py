from django.apps import AppConfig


class BulletinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bulletin'
